#include <stdio.h>
#include <ctype.h>

int main(void)
{
    int c;
    int a = 0, b = 0, d = 0;

    c = getchar();
    while (c != '#' && c != EOF)
    {
        if (isdigit(c))
            a++;
        else if (isalpha(c))
            b++;
        else
            d++;

        c = getchar();
    }

    printf("Digits: %d\n", a);
    printf("Letters: %d\n", b);
    printf("Other: %d\n", d);
    return 0;
}
