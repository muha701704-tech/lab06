#include <stdio.h>
#include <wchar.h>
#include <locale.h>

int main(void)
{
    wint_t c;
    int i, n = 0;

    setlocale(LC_ALL, "");

    // getchar читает байты, getwchar читает широкие символы
    c = getwchar();

    while (c != L'#' && c != WEOF)
    {
        i = 0;
        while (i * i < c)
            i++;

        if (i * i == c)
            n++;

        c = getwchar();
    }

    printf("Count: %d\n", n);
    return 0;
}
