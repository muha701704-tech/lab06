#include <stdio.h>

int main(void)
{
    int n, i;
    double x, r;

    while (1)
    {
        printf("1 - Square\n");
        printf("2 - Cube\n");
        printf("3 - Root\n");
        printf("4 - Cube root\n");
        printf("5 - Exit\n");
        scanf("%d", &n);

        if (n == 5)
            break;

        if (n < 1 || n > 4)
        {
            printf("Error\n");
            continue;
        }

        printf("Number: ");
        scanf("%lf", &x);

        switch (n)
        {
            case 1:
                printf("%.4f\n", x * x);
                break;

            case 2:
                printf("%.4f\n", x * x * x);
                break;

            case 3:
                if (x < 0)
                {
                    printf("Error\n");
                    break;
                }
                r = 1;
                for (i = 0; i < 100; i++)
                    r = (r + x / r) / 2;

                printf("%.4f\n", r);
                break;

            case 4:
                r = 1;
                if (x < 0)
                    r = -1;

                for (i = 0; i < 100; i++)
                    r = (2 * r + x / (r * r)) / 3;

                printf("%.4f\n", r);
                break;
        }
    }
    return 0;
}
