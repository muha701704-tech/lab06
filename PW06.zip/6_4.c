#include <stdio.h>

int main(void)
{
    double x, a = 0, b = 0, c = 0;

    scanf("%lf", &x);
    if (x < 0)
    {
        printf("Error\n");
        return 0;
    }

    if (x <= 20000)
        a = x * 0.02;
    else if (x <= 100000)
    {
        a = 400;
        b = (x - 20000) * 0.03;
    }
    else
    {
        a = 400;
        b = 2400;
        c = (x - 100000) * 0.05;
    }

    printf("Sales: %.2f\n", x);
    printf("2%%: %.2f\n3%%: %.2f\n5%%: %.2f\n", a, b, c);
    printf("Total bonus: %.2f\n", a + b + c);
    return 0;
}
