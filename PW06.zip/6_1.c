#include <stdio.h>
#include <ctype.h>

int main(void)
{
    int c, a = 0, b = 0, d = 0;

    c = getchar();
    while (c != '#' && c != EOF)
    {
        if (isdigit(c)) a++;
        else if (isalpha(c)) b++;
        else d++;
        c = getchar();
    }

    printf("Digits: %d\nLetters: %d\nOther: %d\n", a, b, d);
    return 0;
}
