#include <stdio.h>

int main(void)
{
    int x, a = 0, b = 0;
    double s1 = 0, s2 = 0;

    scanf("%d", &x);
    while (x != 0)
    {
        if (x >= 10 && x <= 50)
        {
            a++;
            s1 = s1 + x;
        }
        else
        {
            b++;
            s2 = s2 + x;
        }
        scanf("%d", &x);
    }

    printf("Group 1: %d\nGroup 2: %d\n", a, b);
    if (a > 0) printf("Average 1: %.2f\n", s1 / a);
    if (b > 0) printf("Average 2: %.2f\n", s2 / b);
    return 0;
}
